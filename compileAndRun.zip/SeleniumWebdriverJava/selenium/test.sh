cd /usr/bin

apt-get update --allow-releaseinfo-change
apt-get update -y
wget -q -O - https://dl-ssl.google.com/linux/linux_signing_key.pub | apt-key add -
echo 'deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main' | tee /etc/apt/sources.list.d/google-chrome.list
apt-get update --allow-releaseinfo-change
apt-get update -y
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
 apt install ./google-chrome-stable_current_amd64.deb
 apt-get -f install -y
export CHROME_BIN=/usr/bin/google-chrome