package com.hackerearth.fullstack.backend;

import org.apache.commons.logging.Log;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.*;
import java.io.File;
import java.io.IOException; // Import the IOException class to handle errors

@Component
public class AutomationScripts {

    static public int count = 0;

    public AutomationScripts() {
        // System.setProperty("webdriver.chrome.driver",
        // "src/main/resources/chromedriver");
    }

    /*
     * Your task is pretty simple and short, just go to the google form with the
     * link "https://forms.gle/vfab7hW7FbERvtym7", fill up the form and submit it.
     * 
     * You have to write the code inside the function  SeleniumAndGoogleForm() which
     * contains 4 parameters 1st one is the driver , 2nd one is the form's URL,  3rd
     * one is "randomName" (the name which you have to enter in the form ) and the
     * 4rd parameter is "tdate"(the date you have to enter in the form ) . 
     * 
     * 
     * 
     * using the driver open the google form with the above link.
     * 
     * When you open the form you will find 2 fields a text field with the
     * title"enter the text given to you" and a date field with the title "date". 
     * 
     * "enter the text given to you": here you have to fill the "randomName" which
     * is provided as a parameter to you.
     * "date": here you have to open the calendar in the google form and fill the
     * date given as a parameter i.e "tdate". then hit submit button and boom your
     * work is done.
     * You Don't have to return anything.
     * 
     * The test cases will then verify your work using the excel response sheet
     * corresponding to the google form.
     * 
     * NOTE: the test cases are designed in such a way that they will verify every
     * operation.
     * 
     * WEBDRIVER: Java selenium webdriver.
     */

    public static Result CompileAndRun(WebDriver driver, String code)
            throws InterruptedException {

        driver.get("https://google.com");
        driver.findElement(By.name("q")).click();
        driver.findElement(By.name("q")).sendKeys("ideone", Keys.RETURN);
        String title = driver.findElement(By.id("result-stats")).getText();
        // console.log(title);

        List<WebElement> linkLocator = driver.findElements(By.tagName("cite"));

        String link1 = linkLocator.get(0).getText();

        driver.get(link1);
        // console.log(link1);
        driver.findElement(By.xpath("//div[@class='dropdown dropup']")).click();
        Thread.sleep(2 * 1000);

        driver.findElement(By.xpath(" //li/a[@id='menu-lang-44']")).click();
        Thread.sleep(3 * 1000);
        driver
                .switchTo()
                .activeElement()
                .sendKeys(Keys.CONTROL + "a");
        driver.switchTo().activeElement().sendKeys(code);

        driver.findElement(By.xpath("//button[@id='Submit']")).click();

        Thread.sleep(5 * 1000);
        String urlide = driver.getCurrentUrl();
        // console.log(urlide);
        driver.get(urlide);
        return new Result(title, link1, urlide);
    }

}