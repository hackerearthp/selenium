package com.hackerearth.fullstack.backend;

import java.util.*;

public class Result {

    public String title;
    public String link;
    public String urlide;

    Result(String title, String link, String urlide) {
        this.title = title;
        this.link = link;
        this.urlide = urlide;

    }

}
