package com.hackerearth.fullstack.backend;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.time.LocalDate;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.boot.test.context.SpringBootTest;

import io.github.bonigarcia.wdm.WebDriverManager;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class AutomationScriptsTest {

    // @Autowired
    private AutomationScripts scripts = new AutomationScripts();
    static private WebDriver driver;
    static private double a = (int) Math.floor(Math.random() * 100001);
    static private double b = (int) Math.floor(Math.random() * 100001);
    static private String code = "#include <iostream> \n using namespace std; \n   int main(){  \n long long int a=" + a
            + ",b="
            + b
            + ";  \n cout<<a+b<<endl; \n }";
    static private String link;
    static private String urlide;

    @BeforeAll
    static void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--no-sandbox", "--disable-dev-shm-usage", "--disable-notifications");
        driver = new ChromeDriver(options);
        Dimension d = new Dimension(1180, 720);
        driver.manage().window().setSize(d);

    }

    @AfterAll
    static void tearDown() {
        driver.quit();
    }

    @Test
    @Order(1)
    void TestingTitle() throws InterruptedException {

        Result result = scripts.CompileAndRun(driver, code);

        assertThat(result.title).contains("seconds");
        link = result.link;
        urlide = result.urlide;

    }

    @Test
    @Order(2)
    void Testinglink() throws InterruptedException {
        assertThat(link).isEqualTo("https://ideone.com");
    }

    @Test
    @Order(3)
    void TestingcompilationResult() throws InterruptedException {

        driver.get("https://google.com");
        Thread.sleep(3 * 1000);
        driver.get(urlide);
        String output = driver.findElement(By.id("output-text")).getText();

        assertThat(output).isEqualTo(Integer.toString((int) a + (int) b));
    }

}