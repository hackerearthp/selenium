cd src/main/resources

content=$(wget https://chromedriver.storage.googleapis.com/LATEST_RELEASE -q -O -)
echo $content



wget https://chromedriver.storage.googleapis.com/$content/chromedriver_linux64.zip
 unzip chromedriver_linux64.zip
 chmod 755 chromedriver

